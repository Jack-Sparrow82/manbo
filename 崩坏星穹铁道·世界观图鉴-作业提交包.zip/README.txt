﻿崩坏：星穹铁道 · 世界观图鉴（网页作业）

主页：index.html（双击即可打开）
分页面：cosmos.html / aeons.html / worlds.html / factions.html / characters.html / glossary.html
样式与交互：styles.css / script.js     图片素材：assets/

【提交说明】
1. 本压缩包请完整解压，得到 hsr-site 文件夹，整体交给老师即可。
   页面之间、页面与图片之间全部使用相对路径，文件夹可任意移动、也可按
   「学号-姓名」重命名，都不会影响显示（便于班级网页汇总）。
2. 请勿只复制 index.html 单个文件，也不要把 assets 文件夹单独移走，
   不要在压缩软件里直接双击 index.html——那样会找不到图片和分页面。

【版权说明】
本页为非官方粉丝向整理，仅用于课程作业展示。
角色立绘、星神画像与图标来自 StarRailRes 开源素材库，
相关角色、商标及美术素材著作权归米哈游（HoYoverse）所有。
